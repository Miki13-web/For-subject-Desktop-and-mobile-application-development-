package source;

public enum HorseCondition {
    healthy,
    sick,
    training,
    sold,
    recovering
}
