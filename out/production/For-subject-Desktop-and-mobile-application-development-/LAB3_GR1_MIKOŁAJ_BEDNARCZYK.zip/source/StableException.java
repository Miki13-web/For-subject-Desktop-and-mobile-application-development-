package source;

public class StableException extends Exception {
    public StableException(String message) {
        super(message);
    }
}
