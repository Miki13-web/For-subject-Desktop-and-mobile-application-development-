package source;

public enum HorseType {
    ColdBlood,
    HotBlood
}
