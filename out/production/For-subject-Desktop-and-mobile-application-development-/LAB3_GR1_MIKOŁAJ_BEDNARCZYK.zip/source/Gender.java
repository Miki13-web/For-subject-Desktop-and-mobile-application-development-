package source;

public enum Gender {
    Mare,
    Stallion,
    Gelding

}
